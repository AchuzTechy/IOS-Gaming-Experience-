#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}


# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

su -c /data/local/tmp/Booster/GameaBoostUnlocker.net
su -c /data/local/tmp/Booster/Booster_Speed
su -c /data/local/tmp/Booster/ADDON_OPS
sysctl -p
##
# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
setprop GameBooster.V1.0
